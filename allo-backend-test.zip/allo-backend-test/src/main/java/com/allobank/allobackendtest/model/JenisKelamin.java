package com.allobank.allobackendtest.model;

public enum JenisKelamin {
    LAKILAKI, PEREMPUAN
}
